# FAZO — statik sayt (GitHub Pages)
Och yashil va och ko‘k aksentlarda, animatsiyalarga boy **statik** (buildsiz) sayt.

## Ishga tushirish
1. Ushbu repoda `Settings → Pages` ga kiring.
2. Branch = **main**, Folder = **/(root)** qilib `Save` qiling.
3. Manzil: `https://USERNAME.github.io/fazo-site/` (USERNAME — GitHub foydalanuvchi nomingiz).

## Fayllar
- `index.html` — asosiy sahifa.
- `site-icon.svg` — favicon/ikonka.
- `robots.txt` — qidiruv uchun ruxsat.
- `sitemap.xml` — sahifa xaritasi (**https://USERNAME.github.io/fazo-site/** ga moslangan).

## Google qidiruv
1. [Google Search Console](https://search.google.com/search-console) ga saytingizni qo‘shing.
2. `Sitemap` maydoniga `https://USERNAME.github.io/fazo-site/sitemap.xml` ni kiriting.
3. “Request indexing” qiling.

> Agar repozitoriyani boshqa nomga qo‘ysangiz, `sitemap.xml` ichidagi manzilni yangi URL bilan almashtiring.
